"""
Report Generation Module
"""

from .pdf_generator import PDFReportGenerator

__all__ = ['PDFReportGenerator']
